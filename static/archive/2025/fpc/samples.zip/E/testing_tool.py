#!/usr/bin/env python3
#
# Testing tool for the Equation Extrapolation problem
#
# Usage:
#
#   python3 testing_tool.py -f inputfile <program invocation>
#
#
# Use the -f parameter to specify the input file, e.g. 1.in.
# The input file should contain two lines:
# - The first line contains a number `d`, the degree of the polynomial.
# - The second line contains the coefficients of the polynomial, `a_0` ... `a_d`.

# You can compile and run your solution as follows:

# C++:
#   g++ solution.cpp
#   python3 testing_tool.py -f 1.in ./a.out

# Python:
#   python3 testing_tool.py -f 1.in python3 ./solution.py

# Java:
#   javac solution.java
#   python3 testing_tool.py -f 1.in java solution

# Kotlin:
#   kotlinc solution.kt
#   python3 testing_tool.py -f 1.in kotlin solutionKt


# The tool is provided as-is, and you should feel free to make
# whatever alterations or augmentations you like to it.
#
# The tool attempts to detect and report common errors, but it is not an exhaustive test.
# It is not guaranteed that a program that passes this testing tool will be accepted.


import argparse
import subprocess
import traceback

parser = argparse.ArgumentParser(description="Testing tool for problem Equation Extrapolation.")
parser.add_argument(
    "-f",
    dest="inputfile",
    metavar="inputfile",
    default=None,
    type=argparse.FileType("r"),
    required=True,
    help="The input file to use.",
)
parser.add_argument("program", nargs="+", help="Invocation of your solution")

args = parser.parse_args()

with (
    args.inputfile as f,
    subprocess.Popen(
        " ".join(args.program),
        shell=True,
        stdout=subprocess.PIPE,
        stdin=subprocess.PIPE,
        universal_newlines=True,
    ) as p,
):
    assert p.stdin is not None and p.stdout is not None
    p_in = p.stdin
    p_out = p.stdout

    def write(line: str):
        assert p.poll() is None, "Program terminated early"
        print(f"Write: {line}", flush=True)
        p_in.write(f"{line}\n")
        p_in.flush()

    def read() -> str:
        assert p.poll() is None, "Program terminated early"
        line = p_out.readline().strip()
        assert line != "", "Read empty line or closed output pipe"
        print(f"Read: {line}", flush=True)
        return line

    # Parse input
    lines = f.readlines()
    d = int(lines[0])
    a = list(map(int, lines[1].split()))

    # Simulate interaction
    try:
        queries = 0
        while True:
            line = read().split()
            if line[0] == "?":
                queries += 1
                x = int(line[1])
                assert -1e6 <= x <= 1e6, "Query not in bounds"
                write(str(sum(b * x**i for i, b in enumerate(a))))
            elif line[0] == "!":
                answer = list(map(int, line[1:]))
                assert len(answer) == len(a), f"Answer contains {len(answer)} coefficients, but should be {len(a)}"
                for i in range(len(a)):
                    assert answer[i] == a[i], f"Answered coefficient a_{i} is {answer[i]}, but should be {a[i]}"
                break
            else:
                assert False, "Line does not start with question or exclamation mark"

        print()
        print("Found the solution.")
        print(f"Queries used: {queries}", flush=True)
        assert (extra := p_out.readline()) == "", (
            f"Your submission printed extra data after finding a solution: '{extra[:100].strip()}{'...' if len(extra) > 100 else ''}'"
        )
        print(f"Exit code: {p.wait()}", flush=True)
        assert p.wait() == 0, "Your submission did not exit cleanly after finishing"

    except AssertionError as e:
        print()
        print(f"Error: {e}")
        print()
        print("Killing your submission.", flush=True)
        p.kill()
        exit(1)

    except Exception:
        print()
        print("Unexpected error:")
        traceback.print_exc()
        print()
        print("Killing your submission.", flush=True)
        p.kill()
        exit(1)
